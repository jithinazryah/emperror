<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">ARRIVED P/S  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->arrived_ps) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">POB INBOUND  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->pob_inbound) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">FIRST LINE ASHORE  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->first_line_ashore) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">ALL FAST  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->all_fast) ?>
    <?= $$newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">AGENT ON BOARD :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->agent_on_board) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">IMMIGRATION CLEARANCE COMMENCED :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->imi_clearence_commenced) ?>
    <?= $newDate; ?>
    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">IMMIGRATION CLEARANCE COMPLETED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->imi_clearence_completed) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">POB OUTBOUND  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->pob_outbound) ?>
    <?= $$newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CAST OFF :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->cast_off) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">LAST LINE AWAY  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->last_line_away) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">CLEARED BREAK WATER  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->cleared_break_water) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">DROP ANCHOR  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->drop_anchor) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">HEAVE UP ANCHOR  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->heave_up_anchor) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
<div class="form-group field-portcalldata-eosp">
    <label class="control-label" for="portcalldata-eosp">PILOT BOARDED  :</label>
    <?= Yii::$app->SetValues->ChangeFormate($imigration->pilot_boarded) ?>
    <?= $newDate; ?>

    <div class="help-block"></div>
</div>
