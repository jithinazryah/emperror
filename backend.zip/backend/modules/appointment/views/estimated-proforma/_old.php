<?php
echo ($model_report->report);
?>