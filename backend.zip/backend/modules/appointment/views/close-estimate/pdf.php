<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title></title>
    </head>
    <body>
        <div style="margin-left: 75px;margin-right: 10px;margin-top: 25px;margin-bottom: 15px;">
            <div class="header">
                <div class="left">
                    <img src="images/logoleft.jpg"/>
                </div>
                <div class="right">
                    <img src="images/logoright.jpg"/>
                </div>
            </div>
        </div>
        <div style="margin-left: 75px;margin-right: 25px">
            <div class="container">
                <form>
                    <table width="1000" border="1">
                        <tr>
                            <td colspan="4" rowspan="2">Address</td>
                            <td colspan="2">Invoice No:</td>
                            <td colspan="2">Invoice Date:</td>

                        </tr>
                        <tr>

                            <td colspan="2">EDPA Ref:</td>
                            <td colspan="2">Customer Code:</td>

                        </tr>
                        <tr>
                            <td colspan="4" rowspan="3">Address</td>
                            <td colspan="2">Vessal Name:</td>
                            <td colspan="2">Oops Reference:</td>

                        </tr>
                        <tr>

                            <td colspan="2">Port of Call:</td>
                            <td colspan="2"></td>

                        </tr>
                        <tr>

                            <td colspan="2">Arrival Date:</td>
                            <td colspan="2">sailind Date</td>

                        </tr>
                    </table>
                </form>
                <h5><b>Disbursement Summary:</b></h5>
                <h5><b>Total Disbursement</b></h5>
                <form>
                    <table width="1000" border="1">
                        <tr>
                            <td>Sl No.</td>
                            <td colspan="5">Particular</td>
                            <td>Invoice Reference</td>
                            <td>Amount</td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td colspan="5">&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="7" style="text-align:center;">Total</td>
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                </form>
                <h5><b>Total Receipts (as pre-funding)</b></h5>
                <form>
                    <table width="1000" border="1">
                        <tr>
                            <td colspan="7" style="text-align:center;">Description</td>
                            <td style="text-align:center;">Amount</td>
                        </tr>
                        <tr>
                            <td colspan="7">&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>

                    </table>
                </form>
                <h5><b>Total Outstanding</b></h5>
                <form>
                    <table width="1000" border="1">
                        <tr>
                            <td colspan="7" style="text-align:center;"><b>Total Due in our favor</b></td>
                            <td>AED 10,820</td>
                        </tr>

                    </table>
                </form>
                <h5><b><i> Amount chargeable (in words)</i></b></h5>
                <h5><b>UAE Dirhams Ten Thousand Eight Hundred Twenty Only</b></h5>
                <p>Company's Bank Details</p>
                <div class="container">
                    <div class="dt1">
                        <form>
                            <table width="300">
                                <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>
                                <tr>
                                    <td>NAME </td>
                                    <td>:emperor</td>
                                </tr>
                                 <tr>
                                    <td>Bank Name</td>
                                    <td>:&nbsp;</td>
                                </tr>
                                <tr>
                                    <td>BRANCH</td>
                                    <td>:branch name</td>
                                </tr>
                                <tr>
                                    <td>Acct NO</td>
                                    <td>:4155663</td>
                                </tr>
                                <tr>
                                    <td>IBAN No</td>
                                    <td>:125478996</td>
                                </tr>
                                <tr>
                                    <td>SWIFT</td>
                                    <td>:address</td>
                                </tr>
                            </table>

                        </form>
                    </div>
                    <div class="dt2">
                        <form>
                            <br/>
                            <br/>
                            <h6><i>Remarks</i></h6>
                            <h5><b>Vessel: Tug Talentlink-3 / Barge Talentlink-5</b></h5>
                        </form>
                    </div>
                </div>
                <br/>
                <br/>
                <br/>
                <div class="container">
                    <div class="dt1">
                        <form>
                            <br/>
                            <br/>
                            <br/>
                            <h6><i>This is computer generated invoice</i></h6>
                        </form>
                    </div>
                    <div class="dt2">
                        <form>
                           
                            <table width="300" border="1">
                                <caption style="text-align: right;">EMPEROR SHIPPING LINES LLC</caption>
                                <tr class="hei">
                                    <td>&nbsp;</td>
                                </tr>
                            </table>
                            <h6 style="text-align: right;"><i>Authorized signaature</i></h6>
                        </form>
                    </div>
                </div>

            </div>
    </body>
</html>
