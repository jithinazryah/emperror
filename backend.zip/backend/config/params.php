<?php

return [
    'adminEmail' => 'admin@example.com',
    'enabled' => 1,
    'disabled' => 0,
];
