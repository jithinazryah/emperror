<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'uploadPath' => '@webroot',
    'estimatePath' => 'estimated-proforma',
    'datPath' => 'port-call-data',
    'closePath' => 'close-estimate',
    'appointmentPath' => 'appointment',
    'mainPath' => 'uploads',
];
