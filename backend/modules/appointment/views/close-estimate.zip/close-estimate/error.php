<div class="col-lg-12 eroors">
        <?php
        echo $error;
        ?>
</div>
<style>
        .eroors{
                background-color: Red;
                height: 46px;
                text-align: center;
                font-size: 30px;
        }
</style>

